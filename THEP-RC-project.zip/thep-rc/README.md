# THEP RC – รีโมทรถ ESP32 + L298N (Bluetooth SPP)

1. อัปโหลดโฟลเดอร์นี้ขึ้น GitHub (ทั้งโฟลเดอร์ รวม .github)
2. แท็บ Actions → Build APK → รอเขียว → ดาวน์โหลด Artifact `THEP-RC-apk`
3. ในมือถือ: Settings → Bluetooth → จับคู่ `THEP_4WD` ก่อน แล้วเปิดแอป → แตะแถบสถานะ → เลือกอุปกรณ์
