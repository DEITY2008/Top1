package com.thep.rc

import android.content.SharedPreferences
import androidx.compose.runtime.*
import kotlin.math.*

enum class Mode { JOY, DUAL, TILT }

val GEARS = listOf("ECO" to 50, "NORMAL" to 75, "TURBO" to 100)

class AppState(private val sp: SharedPreferences) {
    var gear by mutableIntStateOf(sp.getInt("gear", 1).coerceIn(0, 2))
    var mode by mutableStateOf(Mode.entries[sp.getInt("mode", 0).coerceIn(0, 2)])
    var expo by mutableFloatStateOf(sp.getFloat("expo", 0.4f))
    var dead by mutableFloatStateOf(sp.getFloat("dead", 0.08f))
    var haptics by mutableStateOf(sp.getBoolean("hap", true))
    var invSteer by mutableStateOf(sp.getBoolean("is", false))
    var invThr by mutableStateOf(sp.getBoolean("it", false))
    var lastAddr by mutableStateOf<String?>(sp.getString("addr", null))

    var jx by mutableFloatStateOf(0f)
    var jy by mutableFloatStateOf(0f)
    var tankL by mutableFloatStateOf(0f)
    var tankR by mutableFloatStateOf(0f)
    var tiltHold by mutableStateOf(false)
    var tiltS by mutableFloatStateOf(0f)
    var tiltT by mutableFloatStateOf(0f)

    fun save() {
        sp.edit()
            .putInt("gear", gear).putInt("mode", mode.ordinal)
            .putFloat("expo", expo).putFloat("dead", dead)
            .putBoolean("hap", haptics).putBoolean("is", invSteer).putBoolean("it", invThr)
            .putString("addr", lastAddr).apply()
    }

    fun reset() {
        jx = 0f; jy = 0f; tankL = 0f; tankR = 0f
        tiltHold = false; tiltS = 0f; tiltT = 0f
    }

    private fun shape(v: Float): Float {
        val a = abs(v)
        if (a < dead) return 0f
        val n = (a - dead) / (1f - dead)
        return sign(v) * ((1f - expo) * n + expo * n * n * n)
    }

    fun output(): Pair<Int, Int> {
        var l = 0f
        var r = 0f
        when (mode) {
            Mode.JOY -> { val t = shape(jy); val s = shape(jx) * 0.85f; l = t + s; r = t - s }
            Mode.DUAL -> { l = shape(tankL); r = shape(tankR) }
            Mode.TILT -> if (tiltHold) { val t = shape(tiltT); val s = shape(tiltS) * 0.85f; l = t + s; r = t - s }
        }
        val m = max(1f, max(abs(l), abs(r)))
        val lim = GEARS[gear].second
        return (l / m * lim).roundToInt() to (r / m * lim).roundToInt()
    }
}
