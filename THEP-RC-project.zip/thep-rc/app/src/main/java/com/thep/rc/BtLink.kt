package com.thep.rc

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.UUID

data class Cfg(
    val inv: List<Boolean> = List(4) { false },
    val gainL: Int = 100,
    val gainR: Int = 100,
    val ramp: Int = 12
)

enum class LinkState { IDLE, CONNECTING, CONNECTED }

@SuppressLint("MissingPermission")
class BtLink(private val scope: CoroutineScope) {
    private val spp: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    val state = MutableStateFlow(LinkState.IDLE)
    val telL = MutableStateFlow(0)
    val telR = MutableStateFlow(0)
    val cfg = MutableStateFlow(Cfg())
    val fsCount = MutableStateFlow(0)
    val deviceName = MutableStateFlow("")

    private val outCh = Channel<String>(64, BufferOverflow.DROP_OLDEST)
    private var job: Job? = null
    @Volatile private var sock: BluetoothSocket? = null

    fun send(line: String) { outCh.trySend(line) }

    fun connect(dev: BluetoothDevice) {
        disconnect()
        deviceName.value = dev.name ?: dev.address
        job = scope.launch(Dispatchers.IO) {
            while (isActive) {
                state.value = LinkState.CONNECTING
                try {
                    BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
                    val s = dev.createRfcommSocketToServiceRecord(spp)
                    sock = s
                    s.connect()
                    while (outCh.tryReceive().isSuccess) { /* drop stale */ }
                    state.value = LinkState.CONNECTED
                    coroutineScope {
                        launch {
                            for (l in outCh) {
                                s.outputStream.write((l + "\n").toByteArray())
                                s.outputStream.flush()
                            }
                        }
                        send("V"); send("G")
                        val rd = s.inputStream.bufferedReader()
                        while (true) {
                            val line = rd.readLine() ?: break
                            parse(line.trim())
                        }
                        throw java.io.IOException("closed")
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                } finally {
                    try { sock?.close() } catch (_: Exception) {}
                    sock = null
                }
                if (!isActive) break
                state.value = LinkState.CONNECTING
                telL.value = 0; telR.value = 0
                delay(1500)
            }
        }
    }

    fun disconnect() {
        job?.cancel(); job = null
        try { sock?.close() } catch (_: Exception) {}
        sock = null
        state.value = LinkState.IDLE
        telL.value = 0; telR.value = 0
    }

    private fun parse(l: String) {
        val p = l.split(",")
        when (p[0]) {
            "T" -> if (p.size >= 3) {
                telL.value = p[1].toIntOrNull() ?: 0
                telR.value = p[2].toIntOrNull() ?: 0
            }
            "FS" -> fsCount.value += 1
            "CFG" -> if (p.size >= 13) {
                cfg.value = Cfg(
                    inv = (1..4).map { p[it].trim() == "1" },
                    gainL = p[9].trim().toIntOrNull() ?: 100,
                    gainR = p[10].trim().toIntOrNull() ?: 100,
                    ramp = p[12].trim().toIntOrNull() ?: 12
                )
            }
        }
    }
}
