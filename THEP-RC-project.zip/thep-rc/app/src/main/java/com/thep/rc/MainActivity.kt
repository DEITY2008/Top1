package com.thep.rc

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Surface
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@SuppressLint("MissingPermission")
class MainActivity : ComponentActivity() {
    private lateinit var link: BtLink
    private lateinit var st: AppState

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { autoConnect() }

    private fun hasPerm() = Build.VERSION.SDK_INT < 31 ||
        checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun bonded(): List<BluetoothDevice> {
        if (!hasPerm()) return emptyList()
        val ad = getSystemService(BluetoothManager::class.java)?.adapter ?: return emptyList()
        return ad.bondedDevices?.toList() ?: emptyList()
    }

    private fun connect(d: BluetoothDevice) {
        st.lastAddr = d.address
        st.save()
        link.connect(d)
    }

    private fun autoConnect() {
        val a = st.lastAddr ?: return
        bonded().firstOrNull { it.address == a }?.let { link.connect(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        link = BtLink(lifecycleScope)
        st = AppState(getSharedPreferences("thep", Context.MODE_PRIVATE))

        // ส่งคำสั่งขับ 20 ครั้ง/วินาที (ESP32 มี failsafe 0.5 วิ)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (isActive) {
                    if (link.state.value == LinkState.CONNECTED) {
                        val (l, r) = st.output()
                        link.send("M,$l,$r")
                    }
                    delay(50)
                }
            }
        }

        if (Build.VERSION.SDK_INT >= 31 && !hasPerm()) {
            permLauncher.launch(arrayOf(Manifest.permission.BLUETOOTH_CONNECT))
        } else autoConnect()

        setContent {
            TiltEffect(st)
            App(
                st = st, link = link,
                bonded = { bonded() },
                onPick = { connect(it) },
                onBtSettings = { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
                onDisconnect = { st.lastAddr = null; st.save(); link.disconnect() },
                devName = { it.name ?: it.address }
            )
        }
    }

    override fun onStop() {
        super.onStop()
        st.reset()
        link.send("S")
    }
}

@Composable
fun TiltEffect(st: AppState) {
    val ctx = LocalContext.current
    DisposableEffect(st.mode) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (st.mode != Mode.TILT || sensor == null) return@DisposableEffect onDispose { }
        @Suppress("DEPRECATION")
        val rot = (ctx as Activity).windowManager.defaultDisplay.rotation
        var nx = 0f; var ny = 0f; var fx = 0f; var fy = 0f
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val rx = if (rot == Surface.ROTATION_270) e.values[1] else -e.values[1]
                val ry = if (rot == Surface.ROTATION_270) -e.values[0] else e.values[0]
                fx += 0.2f * (rx / 9.81f - fx)
                fy += 0.2f * (ry / 9.81f - fy)
                if (!st.tiltHold) {
                    nx = fx; ny = fy; st.tiltS = 0f; st.tiltT = 0f
                } else {
                    val s = ((fx - nx) / 0.4f).coerceIn(-1f, 1f)
                    val t = ((fy - ny) / 0.4f).coerceIn(-1f, 1f)
                    st.tiltS = if (st.invSteer) -s else s
                    st.tiltT = if (st.invThr) -t else t
                }
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(l) }
    }
}
