package com.thep.rc

import android.bluetooth.BluetoothDevice
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

val Bg = Color(0xFF0B0F1A)
val Panel = Color(0xFF151B2B)
val Cyan = Color(0xFF00E5FF)
val Green = Color(0xFF39FF88)
val Orange = Color(0xFFFF9100)
val Red = Color(0xFFFF3D57)

@Composable
fun App(
    st: AppState, link: BtLink,
    bonded: () -> List<BluetoothDevice>,
    onPick: (BluetoothDevice) -> Unit,
    onBtSettings: () -> Unit,
    onDisconnect: () -> Unit,
    devName: (BluetoothDevice) -> String
) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel)) {
        val state by link.state.collectAsState()
        val tl by link.telL.collectAsState()
        val tr by link.telR.collectAsState()
        val fs by link.fsCount.collectAsState()
        val name by link.deviceName.collectAsState()
        var showSettings by remember { mutableStateOf(false) }
        var showPicker by remember { mutableStateOf(false) }
        var flash by remember { mutableStateOf(false) }
        val hf = LocalHapticFeedback.current

        LaunchedEffect(fs) { if (fs > 0) { flash = true; delay(2000); flash = false } }
        LaunchedEffect(st.gear, st.mode, st.expo, st.dead, st.haptics, st.invSteer, st.invThr) { st.save() }

        val dot = when (state) {
            LinkState.CONNECTED -> Green
            LinkState.CONNECTING -> Orange
            LinkState.IDLE -> Red
        }
        val label = when {
            flash -> "⚠ ขาดสัญญาณ รถหยุดอัตโนมัติ"
            state == LinkState.CONNECTED -> "เชื่อมต่อแล้ว · $name"
            state == LinkState.CONNECTING -> "กำลังเชื่อมต่อ…"
            else -> "แตะเพื่อเลือกอุปกรณ์"
        }

        Box(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Bg, Color(0xFF111A33))))
                .displayCutoutPadding()
        ) {
            Row(Modifier.fillMaxSize().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                // ซ้าย
                Box(Modifier.weight(1f).fillMaxHeight(), Alignment.Center) {
                    when (st.mode) {
                        Mode.JOY -> Stick(Modifier.fillMaxSize(), Cyan) { x, y -> st.jx = x; st.jy = y }
                        Mode.DUAL -> Stick(Modifier.fillMaxSize(), Cyan, vertical = true) { _, y -> st.tankL = y }
                        Mode.TILT -> HoldButton(st)
                    }
                }
                // กลาง
                Column(
                    Modifier.weight(1.15f).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel)
                            .clickable { showPicker = true }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
                        Spacer(Modifier.width(8.dp))
                        Text(label, fontSize = 12.sp, color = if (flash) Orange else Color.White,
                            modifier = Modifier.weight(1f), maxLines = 1)
                        Text("⚙", fontSize = 22.sp, modifier = Modifier.clickable { showSettings = true }.padding(horizontal = 6.dp))
                    }
                    Gauge(max(abs(tl), abs(tr)), Modifier.weight(1f).fillMaxWidth())
                    BiBar("ซ้าย", tl)
                    BiBar("ขวา", tr)
                    Seg(GEARS.map { it.first }, st.gear) {
                        st.gear = it
                        if (st.haptics) hf.performHapticFeedback(HapticFeedbackType.LongPress)
                    }
                    Seg(listOf("จอยเดียว", "ซ้าย-ขวา", "เอียง"), st.mode.ordinal) {
                        st.mode = Mode.entries[it]; st.reset()
                        if (st.haptics) hf.performHapticFeedback(HapticFeedbackType.LongPress)
                    }
                }
                // ขวา
                Box(Modifier.weight(1f).fillMaxHeight(), Alignment.Center) {
                    if (st.mode == Mode.DUAL) {
                        Stick(Modifier.fillMaxSize(), Green, vertical = true) { _, y -> st.tankR = y }
                    } else {
                        Box(
                            Modifier.size(150.dp).clip(CircleShape).background(Red)
                                .clickable {
                                    st.reset(); link.send("S")
                                    if (st.haptics) hf.performHapticFeedback(HapticFeedbackType.LongPress)
                                },
                            Alignment.Center
                        ) { Text("STOP", fontSize = 28.sp, fontWeight = FontWeight.Black, color = Color.White) }
                    }
                }
            }
            if (showSettings) SettingsDialog(st, link, onDisconnect) { showSettings = false }
            if (showPicker) PickerDialog(bonded(), devName, onPick, onBtSettings, onDisconnect) { showPicker = false }
        }
    }
}

@Composable
fun Stick(modifier: Modifier, accent: Color, vertical: Boolean = false, onChange: (Float, Float) -> Unit) {
    var pos by remember { mutableStateOf(Offset.Zero) }
    var sz by remember { mutableStateOf(IntSize.Zero) }
    Box(
        modifier.onSizeChanged { sz = it }.pointerInput(Unit) {
            awaitEachGesture {
                fun radius() = if (vertical) sz.height * 0.38f else min(sz.width, sz.height) * 0.36f
                fun upd(p: Offset) {
                    val r = radius().coerceAtLeast(1f)
                    var d = Offset((p.x - sz.width / 2f) / r, (p.y - sz.height / 2f) / r)
                    if (vertical) d = Offset(0f, d.y)
                    val len = hypot(d.x, d.y)
                    if (len > 1f) d = Offset(d.x / len, d.y / len)
                    pos = d
                    onChange(d.x, -d.y)
                }
                val down = awaitFirstDown()
                upd(down.position)
                while (true) {
                    val ev = awaitPointerEvent()
                    val c = ev.changes.firstOrNull { it.id == down.id } ?: break
                    if (!c.pressed) break
                    upd(c.position); c.consume()
                }
                pos = Offset.Zero
                onChange(0f, 0f)
            }
        }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = if (vertical) size.height * 0.38f else min(size.width, size.height) * 0.36f
            val c = center
            if (vertical) {
                val w = 80.dp.toPx()
                drawRoundRect(Color(0x1AFFFFFF), Offset(c.x - w / 2, c.y - r - 30.dp.toPx()),
                    Size(w, 2 * r + 60.dp.toPx()), CornerRadius(w / 2))
                drawLine(Color(0x55FFFFFF), Offset(c.x - 24.dp.toPx(), c.y), Offset(c.x + 24.dp.toPx(), c.y), 2.dp.toPx())
            } else {
                drawCircle(Color(0x14FFFFFF), r + 26.dp.toPx(), c)
                drawCircle(accent.copy(alpha = .35f), r + 26.dp.toPx(), c, style = Stroke(2.dp.toPx()))
            }
            val k = Offset(c.x + pos.x * r, c.y + pos.y * r)
            drawLine(accent.copy(alpha = .35f), c, k, 6.dp.toPx(), StrokeCap.Round)
            drawCircle(Brush.radialGradient(listOf(accent, accent.copy(alpha = .55f)), k, 36.dp.toPx()), 34.dp.toPx(), k)
        }
    }
}

@Composable
fun HoldButton(st: AppState) {
    val on = st.tiltHold
    Box(
        Modifier.size(170.dp).clip(CircleShape)
            .background(if (on) Green else Panel)
            .border(3.dp, Green, CircleShape)
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown()
                    st.tiltHold = true
                    waitForUpOrCancellation()
                    st.tiltHold = false
                }
            },
        Alignment.Center
    ) {
        Text(if (on) "กำลังขับ\nเอียงเพื่อบังคับ" else "กดค้างไว้\nแล้วเอียงมือถือ",
            textAlign = TextAlign.Center, fontWeight = FontWeight.Bold,
            color = if (on) Color.Black else Color.White)
    }
}

@Composable
fun Gauge(value: Int, modifier: Modifier) {
    val a by animateFloatAsState(value / 100f, label = "gauge")
    Box(modifier, Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = size.minDimension * 0.09f
            val d = size.minDimension - stroke
            val tl = Offset((size.width - d) / 2, (size.height - d) / 2)
            drawArc(Color(0x22FFFFFF), 135f, 270f, false, tl, Size(d, d), style = Stroke(stroke, cap = StrokeCap.Round))
            val col = if (a < .7f) Cyan else if (a < .9f) Orange else Red
            drawArc(col, 135f, 270f * a, false, tl, Size(d, d), style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$value", fontSize = 40.sp, fontWeight = FontWeight.Black, color = Color.White)
            Text("% ความเร็ว", fontSize = 11.sp, color = Color.Gray)
        }
    }
}

@Composable
fun BiBar(label: String, v: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 11.sp, color = Color.Gray, modifier = Modifier.width(34.dp))
        Canvas(Modifier.weight(1f).height(10.dp)) {
            drawRoundRect(Color(0x22FFFFFF), cornerRadius = CornerRadius(5.dp.toPx()), size = size)
            val half = size.width / 2
            val w = half * abs(v) / 100f
            drawRect(if (v >= 0) Green else Orange, Offset(if (v >= 0) half else half - w, 0f), Size(w, size.height))
            drawRect(Color.White.copy(alpha = .6f), Offset(half - 1f, 0f), Size(2f, size.height))
        }
        Text("$v", fontSize = 11.sp, color = Color.White, textAlign = TextAlign.End, modifier = Modifier.width(36.dp))
    }
}

@Composable
fun Seg(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel)) {
        items.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                    .background(if (i == sel) Cyan else Color.Transparent)
                    .clickable { onSel(i) }.padding(vertical = 8.dp),
                Alignment.Center
            ) {
                Text(s, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    color = if (i == sel) Color.Black else Color.White)
            }
        }
    }
}

@Composable
fun SwitchRow(label: String, v: Boolean, on: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp)
        Switch(v, on)
    }
}

@Composable
fun SliderRow(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>,
    fmt: (Float) -> String, onChange: (Float) -> Unit, onDone: () -> Unit = {}
) {
    Column {
        Row {
            Text(label, Modifier.weight(1f), fontSize = 14.sp)
            Text(fmt(value), color = Cyan, fontSize = 14.sp)
        }
        Slider(value, onChange, valueRange = range, onValueChangeFinished = onDone)
    }
}

@Composable
fun SettingsDialog(st: AppState, link: BtLink, onDisconnect: () -> Unit, onClose: () -> Unit) {
    val cfg by link.cfg.collectAsState()
    var gl by remember(cfg.gainL) { mutableFloatStateOf(cfg.gainL.toFloat()) }
    var gr by remember(cfg.gainR) { mutableFloatStateOf(cfg.gainR.toFloat()) }
    var rp by remember(cfg.ramp) { mutableFloatStateOf(cfg.ramp.toFloat()) }
    fun b(x: Boolean) = if (x) 1 else 0

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(0.78f).fillMaxHeight(0.92f), shape = RoundedCornerShape(20.dp), color = Panel) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("ตั้งค่า", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("— ตัวรถ (บันทึกในบอร์ด ESP32) —", color = Color.Gray, fontSize = 12.sp)
                SwitchRow("กลับทิศมอเตอร์ซ้าย", cfg.inv[0]) { link.send("C,0,0,${b(it)}") }
                SwitchRow("กลับทิศมอเตอร์ขวา", cfg.inv[2]) { link.send("C,2,0,${b(it)}") }
                SliderRow("สมดุลแรง ซ้าย", gl, 50f..100f, { "${it.roundToInt()}%" }, { gl = it }) {
                    link.send("K,${gl.roundToInt()},${gr.roundToInt()}")
                }
                SliderRow("สมดุลแรง ขวา", gr, 50f..100f, { "${it.roundToInt()}%" }, { gr = it }) {
                    link.send("K,${gl.roundToInt()},${gr.roundToInt()}")
                }
                SliderRow("การออกตัว (น้อย = นุ่ม)", rp, 3f..30f, { "${it.roundToInt()}" }, { rp = it }) {
                    link.send("A,${rp.roundToInt()}")
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ link.send("T,0") }) { Text("ทดสอบซ้าย") }
                    Button({ link.send("T,1") }) { Text("ทดสอบขวา") }
                    OutlinedButton({ link.send("X") }) { Text("รีเซ็ตรถ") }
                }
                Text("— การควบคุมในแอป —", color = Color.Gray, fontSize = 12.sp)
                SliderRow("ความนุ่มช่วงต้น (Expo)", st.expo, 0f..0.9f, { "${(it * 100).roundToInt()}%" }, { st.expo = it })
                SliderRow("เดดโซนจอย", st.dead, 0f..0.3f, { "${(it * 100).roundToInt()}%" }, { st.dead = it })
                SwitchRow("สั่นเมื่อกดปุ่ม", st.haptics) { st.haptics = it }
                SwitchRow("โหมดเอียง: กลับซ้าย-ขวา", st.invSteer) { st.invSteer = it }
                SwitchRow("โหมดเอียง: กลับหน้า-หลัง", st.invThr) { st.invThr = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onDisconnect) { Text("ตัดการเชื่อมต่อ") }
                    Button(onClose) { Text("ปิด") }
                }
            }
        }
    }
}

@Composable
fun PickerDialog(
    devices: List<BluetoothDevice>, name: (BluetoothDevice) -> String,
    onPick: (BluetoothDevice) -> Unit, onBtSettings: () -> Unit,
    onDisconnect: () -> Unit, onClose: () -> Unit
) {
    Dialog(onDismissRequest = onClose) {
        Surface(shape = RoundedCornerShape(20.dp), color = Panel) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("เลือกรถ (อุปกรณ์ที่จับคู่แล้ว)", fontWeight = FontWeight.Bold)
                if (devices.isEmpty()) Text("ยังไม่พบ — จับคู่ THEP_4WD ในตั้งค่าบลูทูธก่อน", fontSize = 13.sp, color = Color.Gray)
                devices.forEach { d ->
                    Button({ onPick(d); onClose() }, Modifier.fillMaxWidth()) { Text(name(d)) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onBtSettings) { Text("จับคู่ใหม่") }
                    OutlinedButton({ onDisconnect(); onClose() }) { Text("ตัดการเชื่อมต่อ") }
                }
            }
        }
    }
}
